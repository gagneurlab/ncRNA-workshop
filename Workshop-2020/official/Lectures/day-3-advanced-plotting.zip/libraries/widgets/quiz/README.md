jquery.quiz.js
==============

A jQuery plugin that generates interactive quizzes from lists and so on.